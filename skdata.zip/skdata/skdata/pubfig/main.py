
from dataset import PubFig

PubFig().fetch()

