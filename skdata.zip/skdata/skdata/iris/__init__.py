from dataset import Iris
from view import KfoldClassification
