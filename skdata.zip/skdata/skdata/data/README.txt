This folder contains tiny example datasets that are so small, and so static,
that it is OK to check them directly into the git source repo.

Nothing larger than about 50K should be checked in here.

